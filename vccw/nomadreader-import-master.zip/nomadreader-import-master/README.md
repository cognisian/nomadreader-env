# nomadreader-import
A WordPress plugin to search and import book details as WordPress WooCommerce products from the Amazon Affiliate API
