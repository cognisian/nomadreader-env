<?php
defined( 'ABSPATH' ) || die();

add_action('wp_enqueue_scripts', 'nr_theme_enqueue_styles');
add_action('widgets_init', 'nr_homepage1_widgets_init' );
add_action('woocommerce_single_product_summary', 'nr_theme_single_product_details', 6);

add_action('woocommerce_product_meta_start', 'nr_theme_single_product_terms', 40);

add_filter('wc_product_table_language_defaults', 'wcpt_set_language_defaults');
add_filter('woocommerce_product_tabs', 'remove_wc_product_tabs', 98);

/**
 * Add child theme styles and scripts
 */
function nr_theme_enqueue_styles() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css');
}

/**
 * Register our sidebars and widgetized areas.
 */
function nr_homepage1_widgets_init() {

	register_sidebar( array(
		'name'          => 'Homepage_widgets',
		'id'            => 'homepage_widgets',
		'before_widget' => '<div class="homepage_content">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
	) );

}

/**
 * Change the text in the search box
 */
function wcpt_set_language_defaults( $defaults ) {
   $defaults['searchPlaceholder'] = 'Search Places, Titles, Authors';
   return $defaults;
}

/**
 * Hook - WooCommerce Product Summary detals
 */
function nr_theme_single_product_details() {
  global $product;

  $product_id = $product->get_id();

  // Get all of the product_cat terms
  $terms = wp_get_post_terms($product_id, "product_cat", true);

  // Separate the terms into separate lists
  $authors = filter_terms_by_parent_name($terms, 'Authors');
  $genres = filter_terms_by_parent_name($terms, 'Genres');
  $periods = filter_terms_by_parent_name($terms, 'Periods');
  $locations = filter_terms_by_parent_name($terms, 'Location');

  // Send the HTML to render book details
  product_terms_html($authors, 'Authors', 'By');
  
  echo $prooduct->summary;
  
  product_terms_html($genres, 'Genres');
  product_terms_html($periods, 'Periods');
  product_terms_html($locations, 'Location', 'Locations');
}

/**
 * Hook - WooCommerce Product Summary detals
 */
function nr_theme_single_product_terms() {
  echo '';
}

//
// HELPERS
//

/**
 * Render the array of terms to HTML
 */
function product_terms_html($terms, $parent_term_name, $label='') {
  if (empty($label)) {
  	$label = $parent_term_name;
  }
  echo '<div class="'.strtolower($parent_term_name).'"><p class="row-content">';
  echo '<span style="font-weight: bold;">'.$label.'&nbsp;&nbsp;</span>';
  $text = array();
  foreach($terms as $term) {
    $term_link = get_term_link($term, 'product_cat');
    if (!empty($term_link)) {
      $link = '<a href="' . esc_url($term_link) . '" rel="tag">' . $term . '</a>';
    }
  	else {
  	  $link = $term;
  	}
    $text[] = '<span class="item">' . $link . '</span>';
  }
  echo implode(",&nbsp;", $text);
  echo '</p></div>';
}

function remove_wc_product_tabs( $tabs ) {

    unset( $tabs['description'] );      	// Remove the description tab

    return $tabs;
}

/**
 * Given the full set of product_cat terms, filter out all but the terms
 * whose parent term name macthes
 *
 * @param array $post_terms       Array of WP_Terms
 * @param str $parent_post_name   String name of the parent term to filter for
 */
function filter_terms_by_parent_name($post_terms, $parent_term_name) {

  $term_names = array();

  if (!empty($post_terms)) {
    // $parent_term_id = get_toplevel_term($parent_term_name);
    $args_main = array(
      'name'										 => $parent_term_name,
      'parent'                   => 0,
      'orderby'                  => 'term_group',
      'hide_empty'               => false,
      'hierarchical'             => 1,
      'taxonomy'                 => 'product_cat',
      'pad_counts'               => false
    );
    $term = get_terms($args_main);
    if (!is_wp_error($term)) {
      $parent_term_id = $term[0]->term_id;
      $terms = array_filter($post_terms, function($v) use ($parent_term_id) {
        $res = False;
        if ($v->parent == $parent_term_id) {
          $res = True;
        }
        return $res;
      });
      $term_names = array_map(function($v) {
        return $v->name;
      }, $terms);
    }
    else {
      // TODO ERROR processing
    }
  }

  return $term_names;
}

?>
