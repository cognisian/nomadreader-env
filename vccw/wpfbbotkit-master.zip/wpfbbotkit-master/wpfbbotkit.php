<?php
/**
 * Plugin Name: WPFBBotKit
 * Plugin URI: https://jrgould.com
 * Description: A Facebook Messenger Bot Framework for WordPress
 * Version: 1.0.0
 * Author: Jeff Gould
 * Author URI: https://jrgould.com
 * License: GPL2
 */

require_once dirname( __FILE__ ) . '/class/class-wpfbbk-plugin.php';
new WPFBBotKit_Plugin();
